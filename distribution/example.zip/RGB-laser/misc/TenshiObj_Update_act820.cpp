/*
	Ghidra disassembled code of tenshi d236 beams.
	Transcripted by Fishuwako (feat. Gemini)
*/
case 820: {
	if (this->collisionType == 5) {
		this->lifetime--;
		return;
	}
	switch (this->sequenceId) {
	case 0: case 4:
		if (this->parentObjectB == nullptr) { // 失去父物体时自动缩放并销毁逻辑
			this->renderInfo.scale.y = this->renderInfo.scale.x *= 0.9f;
			if (this->renderInfo.scale.x <= 0.1f) {
				this->lifetime--;
				return;
			}
		} else { // 跟随父物体位置
			this->position = this->parentObjectB->position; 
			if (this->parentObjectB->poseId < 2) {
				if (this->currentFrame % 20 == 0) {
					this->createChild(820, this->position.x, this->position.y, this->direction, this->layer, 
						(float[3]){this->renderInfo.rotation.z, 0.0f, 2.0f});
				}
			} else {// 父物体姿态改变后的淡出逻辑
				this->renderInfo.scale.y = this->renderInfo.scale.x *= 0.98f;
				if (this->renderInfo.scale.x <= 0.5f) {
					if (this->renderInfo.color.a < 15) {
						this->lifetime--;
						return;
					}
					this->renderInfo.color.g -= 15;
					this->renderInfo.color.b -= 15;
					this->renderInfo.color.a -= 15;
				}
			}
		}
		break;
		
	case 1: case 5:
		if (this->parentObjectB == nullptr) { 
			if (this->poseId < 2) {
				this->setPose(2);
				this->hitCount = 0;
			}
		} else { // 基于偏移量跟随父物体
			this->position.x = this->parentObjectB->position.x + this->gpFloat[0];
			this->position.y = this->parentObjectB->position.y + this->gpFloat[1];
			
			if (this->poseId == 0) {
				this->gpFloat[2] += 0.1f;
				this->renderInfo.scale.y = this->gpFloat[2] * this->field_0x384;
				if (this->gpFloat[2] >= 1.0f) {
					this->gpFloat[2] = 1.0f;
					this->renderInfo.scale.y = this->field_0x384;
					this->nextPose();
					this->hitCount = 1;
					return;
				}
			}
			if (this->poseId == 1) {
				GameObject::checkGrazed(this, 0); 
			}
		}
		if (this->poseId == 2) { // 姿态2时的淡出与缩减
			if (this->renderInfo.color.g < 15) {
				this->renderInfo.color.g = 0;
				this->renderInfo.color.b = 0;
			} else {
				this->renderInfo.color.g -= 15;
				this->renderInfo.color.b -= 15;
			} /* [8], [6] */
			
			if (this->renderInfo.color.a < 20) {
				this->lifetime--; /* [6], [2] */
				return;
			}
			this->renderInfo.color.a -= 20;
			
			this->renderInfo.scale.y *= 0.95f;
			if (this->renderInfo.scale.y <= 0.01f) {
				this->lifetime--;
				return; 
			}
		}
		break;
		
	case 2:
		if (this->parentObjectB != nullptr) {
			this->position = this->parentObjectB->position;
		}
		this->renderInfo.scale.y = this->renderInfo.scale.x += 0.1f;
		
		// 颜色与透明度衰减
		if (this->renderInfo.color.g >= 15) {
			this->renderInfo.color.g -= 15;
			this->renderInfo.color.b -= 15;
		} else {
			this->renderInfo.color.g = 0;
			this->renderInfo.color.b = 0;
			if (this->renderInfo.color.a < 20) {
				this->lifetime--; /* [9], [10], [2] */
				return;
			}
			this->renderInfo.color.a -= 20;
		}
		break;
		
	case 3:
		if (this->gpShort[0] == 0) { // 检查玩家动作 ID (540-544)
			if (this->parentPlayerB->actionId < 540 || this->parentPlayerB->actionId > 544) {
				Object_CheckTurnIntoCrystal(this, 0, 3, 5); 
				this->gpShort[0]= 2;
				return;
			} else if (this->parentPlayerB->sequenceId > 3) {
				this->gpShort[0]= 2;
				return;
			}

			this->state.updateSpeedAngled(this->customData[0], this->customData[1]);
			this->customData[1] -= 3.0f; 
			if (this->customData[1] < 0.0f) {
				this->customData[1] = 0.0f;
				this->gpShort[0] = 1;
				return;
			}
			// 更新相对偏移并跟随玩家
			this->gpFloat[0] += this->direction * this->speed.x;
			this->gpFloat[1] += this->speed.y;
			this->position.x = this->parentPlayerB->position.x + this->gpFloat[0];
			this->position.y = this->parentPlayerB->position.y + this->gpFloat[1]; 
		}
		
		if (this->gpShort[0] == 1) { 
			// 验证玩家状态
			if (this->parentPlayerB->actionId < 540 || this->parentPlayerB->actionId > 544) {
				Object_CheckTurnIntoCrystal(this, 0, 3, 5); 
				this->gpShort[0]= 2;
				return;
			} else if (this->parentPlayerB->sequenceId > 3) {
				this->gpShort[0]= 2;
				return;
			}
			
			this->position.x = this->parentPlayerB->position.x + this->gpFloat[0];
			this->position.y = this->parentPlayerB->position.y + this->gpFloat[1]; 
			
			// 周期性发射子弹逻辑 (每2帧一次)
			if (this->currentFrame % 2 == 0 && this->gpFloat[2] < 180.0f) { 
				// 发射第一发子弹 (正向角度偏移，包含位置计算与速度复合字面量)
				this->createChild(820, 
					this->position.x + this->direction * CosOneTenthDegree(this->gpFloat[2]) * 20.0f, 
					this->position.y + SinOneTenthDegree(this->gpFloat[2]) * 60.0f, 
					this->direction, 
					this->gpFloat[2] > 90.0f ? 1 : -1, 
					(float[3]){
						-this->customData[3] * SinOneTenthDegree(this->gpFloat[2]), 
						0.0f, 
						(this->parentPlayerB->skillLevelA[2] > 3 ? 5.0f : 1.0f)
					}
				); /* [14], [15], [16] */
				
				// 发射第二发子弹 (180度偏移角度，包含位置计算与速度复合字面量)
				this->createChild(820, 
					this->position.x + this->direction * CosOneTenthDegree(this->gpFloat[2] + 180.0f) * 20.0f, 
					this->position.y + SinOneTenthDegree(this->gpFloat[2] + 180.0f) * 60.0f, 
					this->direction, 
					(this->gpFloat[2] <= -90.0f || this->gpFloat[2] >= 90.0f) ? -1 : 1, 
					(float[3]){
						-this->customData[3] * SinOneTenthDegree(this->gpFloat[2] + 180.0f),
						0.0f, 
						this->parentPlayerB->skillLevelA[2] > 3 ? 5.0f : 1.0f
					}
				); /* [16], [17], [18], [19] */
				
				this->gpFloat[2] += (this->parentPlayerB->skillLevelA[3] > 0 ? 12.0f : 18.0f); /* [14], [19] */
				this->parentPlayerB->playSFX(13); 
			}
		}
		
		if (this->gpShort[0] == 2) { // 最终淡出逻辑
			if (this->renderInfo.color.a >= 10) {
				this->renderInfo.color.a -= 10;
			} else {
				this->lifetime--;
				return;
			}
		}
		break;
	}
	if (AnimationObject_advanceFrame(this)) {
		this->lifetime--;
	}
	return;
}
