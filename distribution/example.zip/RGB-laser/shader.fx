//original sampler
sampler2D Sampler0 : register(s0);
//use this sampler force it to sample texture0 in linear
sampler2D SamplerL0 : register(s0) = sampler_state {
    MinFilter = LINEAR;
    MagFilter = LINEAR;
};
float4 ShaderColor;//general commited by ShaderPro hook, sync with renderInfo.shaderColor
// ------------------------------------------------------------
// Lum Sat
// ------------------------------------------------------------
float Lum(float3 c) {
    return dot(c, float3(0.3, 0.59, 0.11));
}
float Sat(float3 c) {
    return max(c.r, max(c.g, c.b))
         - min(c.r, min(c.g, c.b));
}
// ------------------------------------------------------------
// ClipColor
// limit color to [0, 1] and keep lum
// ------------------------------------------------------------
float3 ClipColor(float3 c)
{
    float l  = Lum(c);
    float mn = min(c.r, min(c.g, c.b));
    float mx = max(c.r, max(c.g, c.b));
    float lowMask = 1.0 - step(0.0, mn);
    float lowDenom = max(l - mn, 0.00001);

    float3 lowColor = l + (c - l) * (l / lowDenom);
    c = lerp(c, lowColor, lowMask);
    float highMask = step(1.00001, mx);
    float highDenom = max(mx - l, 0.00001);
    float3 highColor = l + (c - l) * ((1.0 - l) / highDenom);
    c = lerp(c, highColor, highMask);
    return c;
}
// ------------------------------------------------------------
// SetLum
// ------------------------------------------------------------
float3 SetLum(float3 c, float l) {
    float d = l - Lum(c);
    c += d;
    return ClipColor(c);
}

// ------------------------------------------------------------
// Color Blend
//   Hue        <- Blend
//   Saturation <- Blend
//   Luminosity <- Base
// ------------------------------------------------------------
float3 BlendColor(float3 base, float3 blend) {
    return SetLum(
        blend,
        Lum(base)
    );
}

float4 PS_Recolor(float4 color : COLOR0, float2 tex0 : TEXCOORD0) : COLOR0
{
    float4 t0 = tex2D(SamplerL0, tex0) * color;
    return float4(
        BlendColor(t0.rgb, ShaderColor.rgb),
    color.a);
}

technique Main {
    pass Recolor {
        PixelShader = compile ps_2_0 PS_Recolor();
    }
}