local myShader = nil
---@module "ShaderProLua"
local Sp = nil
soku.SubscribeReady(function()
    Sp = require("RGB-laser/ShaderProLua")
    if Sp then
        Sp.compileFile("RGB-laser", "RGB-laser/shader.fx")
    end
end)
soku.SubscribeBattle(function()
    myShader = Sp and Sp.getShaderType("RGB-laser") or nil
end)

local _colorRainbowFilter = memory.createfunccall(0x48c750, 1, true)
local function colorize(obj, olda)
    local curF = obj.currentFrame
    local hue = curF * 9 + obj.customData[1] * 20
    olda = olda or obj.renderInfo.colorEx.a
    _colorRainbowFilter(obj.ptr, math.floor(hue))
    obj.renderInfo.color = obj.renderInfo.color % 0x100^3 + olda * 0x100^3
    return olda
end

CloseDesyncAlert = true; battle.replaceObjects(soku.Character.Tenshi, 
function (obj, actId, data)
    if obj.owner.character ~= soku.Character.Tenshi then return end
    local seqId, psId, curF = obj.sequenceId, obj.poseId, obj.currentFrame
    ---[[beam
    if actId==820 and (seqId==1 or seqId==5)then
        if myShader then
            local org_color = obj.renderInfo.color
            colorize(obj)
            obj.renderInfo.shaderColor = obj.renderInfo.color
            obj.renderInfo.color = org_color
            obj.renderInfo.shaderType = myShader or 3
        end
        return
    end--]]
    ---[[light-spot
    if actId==820 and (seqId==0 or seqId==4) then
        if myShader then
            obj.renderInfo.shaderType = myShader
            if (obj.parentObjectB) then--use my parent
                obj.renderInfo.shaderColor = obj.parentObjectB.renderInfo.shaderColor
            end
            return
        end
        return
    end--]]
    ---[[ring
    if actId==820 and seqId==2 then
        -- local oldc = obj.renderInfo.color
        -- local olda = colorize(obj)
        if myShader then
            obj.renderInfo.shaderType = myShader
            if obj.parentObjectB then
                obj.renderInfo.shaderColor = obj.parentObjectB.renderInfo.shaderColor
            end
        end
        return
    end--]]
end)